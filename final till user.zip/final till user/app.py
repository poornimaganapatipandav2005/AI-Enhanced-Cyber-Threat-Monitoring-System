from flask import Flask, request, render_template, redirect, url_for, session
import pandas as pd
from datetime import datetime
import os


app = Flask(__name__)
app.secret_key = "cyber_secret_key"

MONITORING_ENABLED = False

LOG_FILE = "logs.xlsx"
USER_FILE = "users.xlsx"
BLOCK_FILE = "blocked_ips.xlsx"

LOG_COLUMNS = [
    "Time", "IP Address", "Endpoint",
    "Method", "User Agent", "Risk Score", "Threat Type"
]

USER_COLUMNS = [
    "First Name", "Last Name", "Email",
    "Mobile", "Gender", "Username", "Password"
]

BLOCK_COLUMNS = [
    "IP Address", "Blocked Time"
]

# -------------------- INIT FILES --------------------

def init_files():

    try:
        if not os.path.exists(LOG_FILE):
            pd.DataFrame(columns=LOG_COLUMNS).to_excel(LOG_FILE, index=False)
        else:
            pd.read_excel(LOG_FILE)

    except:
        pd.DataFrame(columns=LOG_COLUMNS).to_excel(LOG_FILE, index=False)

    try:
        if not os.path.exists(USER_FILE):
            pd.DataFrame(columns=USER_COLUMNS).to_excel(USER_FILE, index=False)
        else:
            pd.read_excel(USER_FILE)

    except:
        pd.DataFrame(columns=USER_COLUMNS).to_excel(USER_FILE, index=False)

    try:
        if not os.path.exists(BLOCK_FILE):
            pd.DataFrame(columns=BLOCK_COLUMNS).to_excel(BLOCK_FILE, index=False)
        else:
            pd.read_excel(BLOCK_FILE)

    except:
        pd.DataFrame(columns=BLOCK_COLUMNS).to_excel(BLOCK_FILE, index=False)

# -------------------- RISK LOGIC --------------------

def calculate_risk(endpoint, user_agent):

    endpoint = (endpoint or "").lower()
    ua = (user_agent or "").lower()

    if "select" in endpoint:
        return 80, "SQL Injection"

    if "<script>" in endpoint:
        return 70, "XSS"

    if "../" in endpoint:
        return 60, "Traversal Attack"

    if "sqlmap" in ua:
        return 75, "Malware"

    if "botnet" in ua:
        return 90, "DDoS"

    if "nmap" in ua:
        return 40, "Port Scan"

    return 5, "Normal"


# -------------------- REQUEST MONITOR --------------------
'''
@app.before_request
def monitor():

    if request.endpoint in ["static", "login", "register", "logout"]:
        return

    if request.endpoint is None:
        return

    if "user" not in session:
        return redirect(url_for("login"))

    init_files()

    ip = request.remote_addr

    # Check if IP is blocked
    block_df = pd.read_excel(BLOCK_FILE)

    if ip in block_df["IP Address"].astype(str).values:
        return "Your IP has been blocked due to suspicious activity."

    endpoint = request.path
    method = request.method
    ua = request.headers.get("User-Agent")

    risk, threat = calculate_risk(endpoint, ua)

    df = pd.read_excel(LOG_FILE)

    df.loc[len(df)] = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ip,
        endpoint,
        method,
        ua,
        int(risk),
        threat
    ]

    df.to_excel(LOG_FILE, index=False)

'''
@app.before_request
def monitor():

    if not MONITORING_ENABLED:
        return   # ❌ Skip logging

    if request.endpoint in ["static", "login", "register", "logout"]:
        return

    if request.endpoint is None:
        return

    if "user" not in session:
        return redirect(url_for("login"))

    init_files()

    ip = request.remote_addr

    block_df = pd.read_excel(BLOCK_FILE)

    if ip in block_df["IP Address"].astype(str).values:
        return "Your IP has been blocked due to suspicious activity."

    endpoint = request.path
    method = request.method
    ua = request.headers.get("User-Agent")

    risk, threat = calculate_risk(endpoint, ua)

    df = pd.read_excel(LOG_FILE)

    df.loc[len(df)] = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ip,
        endpoint,
        method,
        ua,
        int(risk),
        threat
    ]

    df.to_excel(LOG_FILE, index=False)
    
# -------------------- LOGIN --------------------

@app.route("/login", methods=["GET", "POST"])
def login():

    init_files()

    msg = ""

    if request.method == "POST":

        username = request.form["username"].strip()
        password = request.form["password"].strip()

        df = pd.read_excel(USER_FILE)

        df["Username"] = df["Username"].astype(str).str.strip()
        df["Password"] = df["Password"].astype(str).str.strip()

        match = df[
            (df["Username"] == username) &
            (df["Password"] == password)
        ]

        if not match.empty:
            session["user"] = username
            return redirect(url_for("dashboard"))

        else:
            msg = "Invalid username or password"

    return render_template("login.html", msg=msg)


# -------------------- REGISTER --------------------

@app.route("/register", methods=["GET", "POST"])
def register():

    init_files()

    msg = ""

    if request.method == "POST":

        data = {
            "First Name": request.form["fname"].strip(),
            "Last Name": request.form["lname"].strip(),
            "Email": request.form["email"].strip(),
            "Mobile": request.form["mobile"].strip(),
            "Gender": request.form["gender"].strip(),
            "Username": request.form["username"].strip(),
            "Password": request.form["password"].strip()
        }

        df = pd.read_excel(USER_FILE)

        if (df["Username"].astype(str).str.strip() == data["Username"]).any():
            msg = "Username already exists"

        else:
            df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
            df.to_excel(USER_FILE, index=False)

            return redirect(url_for("login"))

    return render_template("register.html", msg=msg)


# -------------------- DASHBOARD --------------------
@app.route("/")
def dashboard():

    if "user" not in session:
        return redirect(url_for("login"))

    init_files()

    try:
        df = pd.read_excel(LOG_FILE)
    except:
        df = pd.DataFrame(columns=LOG_COLUMNS)

    # -------------------- CLEAN DATA --------------------
    df["Risk Score"] = pd.to_numeric(df["Risk Score"], errors="coerce").fillna(0)
    df["Time"] = pd.to_datetime(df["Time"], errors="coerce")

    today = datetime.now().date()
    today_df = df[df["Time"].dt.date == today]

    # -------------------- COUNTS --------------------
    total_threats = today_df[today_df["Risk Score"] >= 40].shape[0]

    malware_count = today_df[
        today_df["Threat Type"].str.contains("Malware", case=False, na=False)
    ].shape[0]

    sql_count = today_df[
        today_df["Threat Type"].str.contains("SQL", case=False, na=False)
    ].shape[0]

    ddos_count = today_df[
        today_df["Threat Type"].str.contains("DDoS", case=False, na=False)
    ].shape[0]

    avg_risk = today_df["Risk Score"].mean() if not today_df.empty else 0

    # -------------------- THREAT LEVEL --------------------
    if avg_risk >= 70:
        threat_level = "HIGH 🔴"
    elif avg_risk >= 40:
        threat_level = "MEDIUM 🟠"
    else:
        threat_level = "LOW 🟢"

    # -------------------- DISTRIBUTION --------------------
    low_count = today_df[today_df["Risk Score"] < 40].shape[0]

    medium_count = today_df[
        (today_df["Risk Score"] >= 40) &
        (today_df["Risk Score"] < 70)
    ].shape[0]

    high_count = today_df[today_df["Risk Score"] >= 70].shape[0]

    # -------------------- RECENT LOGS --------------------
    logs_df = df.tail(10).copy()

    # ✅ Add STATUS column (IMPORTANT)
    logs_df["Status"] = logs_df["Risk Score"].apply(
        lambda x: "SAFE" if int(x) < 40 else "ATTACK"
    )

    logs = logs_df.to_dict(orient="records")

    return render_template(
        "dashboard.html",
        logs=logs,
        total_threats=total_threats,
        malware_count=malware_count,
        sql_count=sql_count,
        ddos_count=ddos_count,
        threat_level=threat_level,
        low_count=low_count,
        medium_count=medium_count,
        high_count=high_count,
        username=session.get("user")
    )   
# -------------------- BLOCK IP --------------------

@app.route("/block_ip/<ip>")
def block_ip(ip):

    if "user" not in session:
        return redirect(url_for("login"))

    df = pd.read_excel(BLOCK_FILE)

    if ip not in df["IP Address"].astype(str).values:

        df.loc[len(df)] = [
            ip,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ]

        df.to_excel(BLOCK_FILE, index=False)

    return redirect(url_for("dashboard"))


# -------------------- MALWARE SIMULATION --------------------
@app.route("/simulate_malware")
def simulate_malware():

    init_files()
    df = pd.read_excel(LOG_FILE)

    df.loc[len(df)] = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "10.0.0.5",
        "/admin",
        "POST",
        "sqlmap malware scanner",
        80,
        "Malware"
    ]

    df.to_excel(LOG_FILE, index=False)

    return redirect(url_for("dashboard"))
# -------------------- SQL INJECTION SIMULATION --------------------

@app.route("/simulate_sql")
def simulate_sql():

    init_files()
    df = pd.read_excel(LOG_FILE)

    df.loc[len(df)] = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "45.23.11.90",
        "/login?user=admin' OR '1'='1",
        "GET",
        "sqlmap scanner",
        85,
        "SQL Injection"
    ]

    df.to_excel(LOG_FILE, index=False)

    return redirect(url_for("dashboard"))
# -------------------- DDOS SIMULATION --------------------

@app.route("/simulate_ddos")
def simulate_ddos():

    init_files()
    df = pd.read_excel(LOG_FILE)

    df.loc[len(df)] = [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "192.168.0.1",
        "/api/data",
        "GET",
        "botnet ddos tool",
        90,
        "DDoS"
    ]

    df.to_excel(LOG_FILE, index=False)

    return redirect(url_for("dashboard"))

@app.route("/start_monitoring")
def start_monitoring():
    global MONITORING_ENABLED
    MONITORING_ENABLED = True
    return redirect(url_for("dashboard"))

@app.route("/stop_monitoring")
def stop_monitoring():
    global MONITORING_ENABLED
    MONITORING_ENABLED = False
    return redirect(url_for("dashboard"))

@app.route("/clear_logs", methods=["POST"])
def clear_logs():

    if "user" not in session:
        return redirect(url_for("login"))

    pd.DataFrame(columns=LOG_COLUMNS).to_excel(LOG_FILE, index=False)

    return redirect(url_for("dashboard"))

@app.route("/details/<attack_type>")
def details(attack_type):

    if "user" not in session:
        return redirect(url_for("login"))

    try:
        df = pd.read_excel(LOG_FILE)
    except:
        df = pd.DataFrame(columns=LOG_COLUMNS)

    df["Risk Score"] = pd.to_numeric(df["Risk Score"], errors="coerce").fillna(0)
    df["Time"] = pd.to_datetime(df["Time"], errors="coerce")

    today = datetime.now().date()
    df = df[df["Time"].dt.date == today]

    # ---------------- FILTER ----------------
    if attack_type == "malware":
        filtered = df[df["Threat Type"].str.contains("Malware", case=False, na=False)]

    elif attack_type == "sql":
        filtered = df[df["Threat Type"].str.contains("SQL", case=False, na=False)]

    elif attack_type == "ddos":
        filtered = df[df["Threat Type"].str.contains("DDoS", case=False, na=False)]

    elif attack_type == "total":
        filtered = df[df["Risk Score"] >= 40]

    else:
        filtered = df

    # ---------------- TABLE ----------------
    records = filtered.to_dict(orient="records")

    # ---------------- GRAPH (SAFE 24 HOURS) ----------------
    try:
        filtered["Hour"] = filtered["Time"].dt.hour
        grouped = filtered.groupby("Hour").size()

        graph_data = {str(i): 0 for i in range(24)}

        for hour, count in grouped.items():
            graph_data[str(hour)] = int(count)

    except:
        # fallback if anything fails
        graph_data = {str(i): 0 for i in range(24)}

    # ✅ IMPORTANT: ALWAYS RETURN
    return render_template(
        "details.html",
        records=records,
        graph_data=graph_data,
        attack_type=attack_type
    )

@app.route("/api/chart-data")
def chart_data():

    df = pd.read_excel(LOG_FILE)

    df["Risk Score"] = pd.to_numeric(df["Risk Score"], errors="coerce").fillna(0)

    low = df[df["Risk Score"] < 40].shape[0]
    medium = df[(df["Risk Score"] >= 40) & (df["Risk Score"] < 70)].shape[0]
    high = df[df["Risk Score"] >= 70].shape[0]

    return {
        "low": int(low),
        "medium": int(medium),
        "high": int(high)
    }
import requests

@app.route("/map")
def attack_map():

    if "user" not in session:
        return redirect(url_for("login"))

    df = pd.read_excel(LOG_FILE)

    df = df[df["Risk Score"] >= 40]  # only attacks

    locations = []

    for _, row in df.iterrows():
        ip = row["IP Address"]

        try:
            res = requests.get(f"http://ip-api.com/json/{ip}").json()

            if res["status"] == "success":
                locations.append({
                    "ip": ip,
                    "lat": res["lat"],
                    "lon": res["lon"],
                    "country": res["country"],
                    "threat": row["Threat Type"]
                })

        except:
            continue

    return render_template("map.html", locations=locations)
@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")
'''
@app.route("/edit_profile", methods=["GET", "POST"])
def edit_profile():

    if "user" not in session:
        return redirect(url_for("login"))

    df = pd.read_excel(USER_FILE)

    # Clean columns
    df.columns = df.columns.str.strip()

    # Normalize username
    df["Username"] = df["Username"].astype(str).str.strip().str.lower()
    username = session["user"].strip().lower()

    # Find user
    user_row = df[df["Username"] == username]

    if user_row.empty:
        return "User not found"

    # UPDATE DATA
    if request.method == "POST":

        df.loc[df["Username"] == username, "First Name"] = request.form.get("fname", "").strip()
        df.loc[df["Username"] == username, "Last Name"] = request.form.get("lname", "").strip()
        df.loc[df["Username"] == username, "Email"] = request.form.get("email", "").strip()
        df.loc[df["Username"] == username, "Mobile"] = request.form.get("mobile", "").strip()
        df.loc[df["Username"] == username, "Password"] = request.form.get("password", "").strip()

        df.to_excel(USER_FILE, index=False)

        return redirect(url_for("dashboard"))

    # Fix NaN issue
    user = user_row.fillna("").iloc[0].to_dict()

    return render_template("edit_profile.html", user=user)'''

# -------------------- LOGOUT --------------------

@app.route("/logout")
def logout():

    session.clear()
    return redirect(url_for("login"))


# -------------------- RUN --------------------

if __name__ == "__main__":

    init_files()

    app.run(debug=True)
